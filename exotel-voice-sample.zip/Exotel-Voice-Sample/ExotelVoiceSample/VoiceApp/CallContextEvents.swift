/*
 * Copyright (c) 2022 Exotel Techcom Pvt Ltd
 * All rights reserved
 */

import Foundation

public protocol CallContextEvents {
    func onGetContextSuccess()
}
