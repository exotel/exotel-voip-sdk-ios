/*
 * Copyright (c) 2022 Exotel Techcom Pvt Ltd
 * All rights reserved
 */

import UIKit

class KeypadCell: UICollectionViewCell {
    @IBOutlet weak var numbersLbl: UILabel!
}
