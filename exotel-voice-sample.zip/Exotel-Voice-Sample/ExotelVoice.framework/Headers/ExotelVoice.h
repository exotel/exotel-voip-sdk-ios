/*
 * Copyright (c) 2022 Exotel Techcom Pvt Ltd
 * All rights reserved
 */

#import <Foundation/Foundation.h>

//! Project version number for ExotelVoice.
FOUNDATION_EXPORT double ExotelVoiceVersionNumber;

//! Project version string for ExotelVoice.
FOUNDATION_EXPORT const unsigned char ExotelVoiceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <jetixiOS/PublicHeader.h>
#import "CloudonixSDKClient.h"
#import "iOSDataTypes.h"
#import "AudioSessionManager.h"
